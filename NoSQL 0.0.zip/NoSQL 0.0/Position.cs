﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoSQL_0._0
{
    enum Position
    {
        Employee,
        Location_Manager,
        Corporate_Sales_Manager
    }
}
