﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoSQL_0._0
{
    enum City
    {
        Malmö1,
        Malmö2,
        Malmö3,
        London,
        Minneapolis,
        Chicago
    }
}
